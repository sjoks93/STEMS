mapping = {
    "default": {
        "core_allocation": [0,],
    },
    "Conv": {
        "core_allocation": [0,],
    },
    "Gemm": {
        "core_allocation": [0,],
    },
    "Pool": {
        "core_allocation": 1,
    },
    "MaxPool": {
        "core_allocation": 1,
    },
    "AveragePool": {
        "core_allocation": 1,
    },
    "GlobalAveragePool": {
        "core_allocation": 1,
    },
    "Add": {
        "core_allocation": 0,
    },
}
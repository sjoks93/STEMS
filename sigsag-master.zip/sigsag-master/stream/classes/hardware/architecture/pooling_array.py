from zigzag.classes.hardware.architecture.operational_array import OperationalArray


class PoolingArray(OperationalArray):
    pass

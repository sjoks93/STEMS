mapping = {
    "default": {
        "core_allocation": 0,
    },
    "pooling": {
        "core_allocation": 4,
    },
    "simd": {
        "core_allocation": 5,
    }
}